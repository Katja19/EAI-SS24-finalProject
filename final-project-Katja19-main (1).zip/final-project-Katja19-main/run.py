from pipelines import training_pipeline

training_pipeline()